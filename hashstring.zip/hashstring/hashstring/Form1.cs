﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hashstring
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string hash = "";
        private void button1_Click(object sender, EventArgs e)
        {

            hash = BCrypt.Net.BCrypt.HashPassword(textBox1.Text);
            MessageBox.Show(hash);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool verify = BCrypt.Net.BCrypt.Verify(textBox2.Text, hash);
            if (verify)
            {
                {
                    MessageBox.Show("right");
                }
            }
            else
            {
                MessageBox.Show("wrong");
            }
        }
    }
}
